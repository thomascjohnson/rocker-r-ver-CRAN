# `generics` 0.0.2

* Removed the `data` argument to `augment` to resolve issues with `broom`. 


# `generics` 0.0.1

First CRAN version


